# Todo

1. 価格変動の20日平均でZscoreを出す。

